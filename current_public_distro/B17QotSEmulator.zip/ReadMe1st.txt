B-17: Queen of the Skies Emulator

--------------------------------------------------------------------------------

1.0b3 Installation Instructions

1) No changes were made to the database. If don't want to lose your data, save
   B17QotSDatabase.mdb to B17QotSDatabase_Keep.mdb. 

2) If you have an existing emulator installation, use Windows Control Panel to
   remove it.

3) Create the folder where you want the game files to reside.

4) Extract B17QotSEmulator.zip to the new folder.

5) Click setup.exe. Wait until it is done expanding the .cab file.

6) Delete the B17QotSDatabase.mdb that was just unpacked. Rename 
   B17QotSDatabase_Keep.mdb to B17QotSDatabase.mdb.

7) Single right click B17QotSEmulator.exe. Click "Copy".

8) Navigate to the folder where you want the game shortcut to reside. 

9) Right click in the folder. Click "Paste Shortcut".

10) Double left click the shortcut to run the emulator.

--------------------------------------------------------------------------------

B-17: Queen of the Skies Emulator (c) Preston McMurry, 2004-2005
"B-17: Queen of the Skies", (c) The Avalon Hill Game Company, 1982

